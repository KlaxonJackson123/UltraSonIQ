# Init for ScanIQ UI module
