# API routes for ScanIQ frontend
