# docs/modules/scaniq/README.md
Documentation for ScanIQ core engine
