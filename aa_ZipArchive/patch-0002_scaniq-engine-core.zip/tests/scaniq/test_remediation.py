# tests/scaniq/test_remediation.py
Unit tests for remediation logic
