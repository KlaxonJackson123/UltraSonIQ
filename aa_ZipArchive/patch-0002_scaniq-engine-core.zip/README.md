# README.md
ScanIQ Engine Core - Patch 0002
This patch contains the full production-grade core scanning and remediation logic for Azure CIS controls.
