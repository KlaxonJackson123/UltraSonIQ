# modules/scaniq/utils/helpers.py
Helper functions for scanning and parsing
