# patch-0005_scaniq-core-engine

Full implementation of the ScanIQ core scanning engine with remediation hooks and Azure CIS benchmark rule set coverage. Includes CLI runner, API interface, logging, and results processing.

